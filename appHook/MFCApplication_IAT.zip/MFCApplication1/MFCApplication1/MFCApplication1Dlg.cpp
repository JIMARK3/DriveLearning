
// MFCApplication1Dlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "MFCApplication1.h"
#include "MFCApplication1Dlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CMFCApplication1Dlg �Ի���



CMFCApplication1Dlg::CMFCApplication1Dlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CMFCApplication1Dlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMFCApplication1Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST1, m_list);
}

BEGIN_MESSAGE_MAP(CMFCApplication1Dlg, CDialogEx)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_NOTIFY(LVN_GETDISPINFO, IDC_LIST1, &CMFCApplication1Dlg::OnLvnGetdispinfoList1)
	ON_BN_CLICKED(IDC_BUTTON1, &CMFCApplication1Dlg::OnBnClickedButton1)
END_MESSAGE_MAP()


// CMFCApplication1Dlg ��Ϣ��������

BOOL CMFCApplication1Dlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// ���ô˶Ի����ͼ�ꡣ  ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���
	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��

	// TODO:  �ڴ����Ӷ���ĳ�ʼ������
	DWORD dwStyle = m_list.GetExtendedStyle();
	dwStyle |= LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES | LVS_EX_CHECKBOXES | LVS_EX_INFOTIP | LVS_EX_DOUBLEBUFFER;
	m_list.SetExtendedStyle(dwStyle);
	m_list.InsertColumn(0, L"ID", LVCFMT_LEFT, 390);
	m_list.InsertColumn(1, L"DLL", LVCFMT_LEFT, 390);
	m_list.InsertColumn(2, L"FUNC", LVCFMT_LEFT, 390);
	m_list.InsertColumn(3, L"ADDR", LVCFMT_LEFT, 390);


	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

// �����Ի���������С����ť������Ҫ����Ĵ���
//  �����Ƹ�ͼ�ꡣ  ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
//  �⽫�ɿ���Զ���ɡ�

void CMFCApplication1Dlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ���ڻ��Ƶ��豸������

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// ʹͼ���ڹ����������о���
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// ����ͼ��
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù��
//��ʾ��
HCURSOR CMFCApplication1Dlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


#include<vector>
#include<psapi.h>
typedef struct ListItem
{
	char  dllName[100];
	char funcName[100];
	char addr[100];
}ListItem;
void CreateList_data(PIMAGE_IMPORT_DESCRIPTOR describes);
std::vector<ListItem> items;

char  dllNameTemp[100] = {0};
DWORD base;

void CMFCApplication1Dlg::OnLvnGetdispinfoList1(NMHDR *pNMHDR, LRESULT *pResult)
{
	NMLVDISPINFO *pDispInfo = reinterpret_cast<NMLVDISPINFO*>(pNMHDR);
	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	LV_ITEM* pItem = &(pDispInfo)->item;

	if (pItem == NULL) return;
	CString strCell;
	int iItemIndx = pItem->iItem;//��������������Ƶ���ʼλ��
	if (pItem->mask & LVIF_TEXT)
	{
		switch (pItem->iSubItem)//iSubitemָ��
		{
		case 0:
		{
			char buffer[10];
			strCell = itoa(iItemIndx, buffer, 10);
			lstrcpy(pItem->pszText, strCell);

		}
			break;
		case 1:
		{
			strCell = items[iItemIndx].dllName;
			lstrcpy(pItem->pszText, strCell);
		}
			break;
		case 2:
		{
			strCell = items[iItemIndx].funcName;
			lstrcpy(pItem->pszText, strCell);
		}
			break;
		case 3:
		{
			strCell = items[iItemIndx].addr;
			lstrcpy(pItem->pszText, strCell);
		}
			break;
		}
	}


	*pResult = 0;
}




void CreateList_data(IMAGE_IMPORT_DESCRIPTOR describes, HANDLE hProcess){

	
	PIMAGE_THUNK_DATA pthunk_data = (PIMAGE_THUNK_DATA)(describes.OriginalFirstThunk + base);
	IMAGE_THUNK_DATA thunk_data;
	ReadProcessMemory(hProcess, pthunk_data, &thunk_data, sizeof(IMAGE_THUNK_DATA), NULL);

	LPVOID piat_entrys = (LPVOID)(describes.FirstThunk + base);

	while (thunk_data.u1.Function != NULL)

	{
		PIMAGE_IMPORT_BY_NAME pby_name = (PIMAGE_IMPORT_BY_NAME)(thunk_data.u1.Function + base);
		char func_name[100] = {0};
		ReadProcessMemory(hProcess, (LPVOID)(pby_name ), func_name, 100, NULL);
		
		DWORD iat_entry;
		ReadProcessMemory(hProcess, (LPVOID)piat_entrys, &iat_entry, 4, NULL);
		
		ListItem item;
		sprintf_s(item.dllName, "%s", dllNameTemp);
		sprintf_s(item.funcName, "%s", (char *)(&(func_name[2])));
		itoa(iat_entry, item.addr, 16);
		items.push_back(item);

		pthunk_data++;
		ReadProcessMemory(hProcess, pthunk_data, &thunk_data, sizeof(IMAGE_THUNK_DATA), NULL);
		piat_entrys = (LPVOID)((DWORD)piat_entrys +4);

	}

}

void CMFCApplication1Dlg::OnBnClickedButton1()
{
	// TODO:  �ڴ����ӿؼ�֪ͨ�����������
	items.clear();

	char text[256];
	GetDlgItemTextA(this->m_hWnd, IDC_EDIT1, text, 255);

	DWORD pid = strtol(text, NULL, 10);

	HANDLE hProcess = OpenProcess(PROCESS_ALL_ACCESS, false, pid);
	
	HMODULE hModule[100] = { 0 };
	DWORD dwRet = 0;
	BOOL bRet = ::EnumProcessModules(hProcess, (HMODULE *)(hModule), sizeof(hModule), &dwRet);
	if (FALSE == bRet)
	{
		return;

	}
	// ��ȡ��һ��ģ����ػ�ַ
	PVOID pProcessImageBase = hModule[0];
	base = (DWORD)pProcessImageBase;
	PIMAGE_DOS_HEADER pdos_header = (PIMAGE_DOS_HEADER) base;
	IMAGE_DOS_HEADER dos_header;
	ReadProcessMemory(hProcess, (LPVOID)base, &dos_header, sizeof(IMAGE_DOS_HEADER),NULL);
	
	LONG e_lfanew = dos_header.e_lfanew;
	PIMAGE_NT_HEADERS pnt_header = (PIMAGE_NT_HEADERS)(base + (DWORD)e_lfanew);
	IMAGE_NT_HEADERS nt_header;
	ReadProcessMemory(hProcess, (LPVOID)pnt_header, &nt_header, sizeof(IMAGE_NT_HEADERS), NULL);

	IMAGE_DATA_DIRECTORY data_dir = nt_header.OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];

	PIMAGE_IMPORT_DESCRIPTOR pdescribes = (PIMAGE_IMPORT_DESCRIPTOR)(data_dir.VirtualAddress + base);

	while (1)
	{
		IMAGE_IMPORT_DESCRIPTOR describes;
		ReadProcessMemory(hProcess, (LPVOID)pdescribes, &describes, sizeof(IMAGE_IMPORT_DESCRIPTOR), NULL);
	
		if (describes.Name==NULL)
		{
			break;
		}
		LPVOID pname = (LPVOID)(describes.Name + base);
		char name_buffer[100];
		ReadProcessMemory(hProcess, pname, name_buffer, 100, NULL);
		sprintf_s(dllNameTemp, "%s", name_buffer);

		CreateList_data(describes,hProcess);
		pdescribes++;
	}

	DWORD iCount = items.size();
	m_list.DeleteAllItems();

	m_list.SetItemCountEx(iCount);//�����б�Ҫ��ʾ��������	
	m_list.RedrawItems(0, iCount);
}
